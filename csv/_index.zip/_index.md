---
title: Home
sections:
  - type: slider_section
    template: slider_section
    slide: true
    slides:
      - cover: /images/home/slider_1.jpg
        title: Handmade Hand Carved Coffee
        subtitle: As rich and unique as the coffee beans it is intended for, this little scoop will make your morning ritual a special occasion every day.
        button_text: order now
        button_link: /order
      - cover: /images/home/slider_2.jpg
        title: Think different Do otherwise
        subtitle: Claritas est etiam processus dynamicus, qui sequitur mutationem <br> consuetudium lectorum.
        button_text: order now
        button_link: /order
      - cover: /images/home/slider_3.jpg
        title:  High Beam <br>by Tom Chung
        subtitle:  High Beam is an adjustable desk or shelf light that offers a wide variety of <br> lighting possibilities.
        button_text: order now
        button_link: /order
      - cover: /images/home/slider_2.jpg
        title:  High Beam <br>by Tom Chung
        subtitle:  High Beam is an adjustable desk or shelf light that offers a wide variety of <br> lighting possibilities.
        button_text: order now
        button_link: /order
  - type: block_image_features
    template: block_image_features
    images:
      - image: /images/home/banner_01.webp
        title: jaket hijaber
        url: /product
      - image: /images/home/banner_02.webp
        title: Tunic
        url: /collections
      - image: /images/home/banner_03.webp
        title: Home Dress
        url: /collections
      - image: /images/home/banner_04.webp
        title: Micro Mask
        url: /collection/micro-mask-basic
    design:
      container: true
      column: 4
      background:
        color: '#fff'
  - type: features_section
    template: features_section
    title: Features
    features:
      - type: feature
        template: feature
        title: Feature 1
        content: >-
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec nisl
          ligula, cursus id molestie vel, maximus aliquet risus. Vivamus in nibh
          fringilla, fringilla.
        align: left
        image: images/feature.svg
        image_position: right
        actions:
          - type: action
            template: action
            label: Learn More
            url: /features
            style: secondary
      - type: feature
        template: feature
        title: Feature 2
        content: >-
          Ac felis donec et odio pellentesque. Sagittis vitae et leo duis ut
          diam quam nulla. Ullamcorper a lacus vestibulum sed arcu non odio
          euismod lacinia.
        align: left
        image: images/feature.svg
        image_position: left
        actions:
          - type: action
            template: action
            label: Learn More
            url: /features
            style: secondary
      - type: feature
        template: feature
        title: Feature 3
        content: >-
          Id nibh tortor id aliquet lectus proin. Amet venenatis urna cursus
          eget nunc. Lacus sed turpis tincidunt id aliquet risus feugiat in
          ante.
        align: left
        image: images/feature.svg
        image_position: right
        actions:
          - type: action
            template: action
            label: Learn More
            url: /features
            style: secondary
  - type: blog_feed_section
    template: blog_feed_section
    title: What's New
    show_recent: true
    recent_count: 3
  - type: cta_section
    template: cta_section
    title: This Is A CTA
    subtitle: >-
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam a metus
      quis lorem malesuada luctus.
    actions:
      - type: action
        template: action
        label: Learn More
        url: /features
        style: primary
    has_background: true
    background_color: gray
layout: advanced
---
